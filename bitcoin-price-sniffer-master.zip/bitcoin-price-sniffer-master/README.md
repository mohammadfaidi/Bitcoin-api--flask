# Bitcoin Price Sniffer

![Bitcoin](images/Bitcoin.jpg)

## What I did

Bitcoin price program using [CoinDesk](https://www.coindesk.com/coindesk-api) API with Python.

## Output Sample

```bash
The price in United States Dollar - USD: 4,831.9167
Time of the price: Mar 16, 2020 09:53:00 UTC
```

## License
[MIT](LICENSE)